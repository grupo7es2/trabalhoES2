package MyApp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullResult;
import org.eclipse.jgit.api.errors.CanceledException;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidConfigurationException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.api.errors.RefNotAdvertisedException;
import org.eclipse.jgit.api.errors.RefNotFoundException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.api.errors.WrongRepositoryStateException;
import org.eclipse.jgit.lib.Constants;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectLoader;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;
import org.eclipse.jgit.util.FS;
import static java.io.File.separator;
import static org.eclipse.jgit.lib.RepositoryCache.FileKey.isGitRepository;

/**
 * Hello world!
 *
 */

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;



public class App implements Serializable {

	public FileRepositoryBuilder repo;
	public Repository repository;
	public File file;
	static ArrayList<String> resp;
	private final String GIT_URI = "https://github.com/vbasto-iscte/ESII1920.git";
	private final String GIT_FOLDER = ".git";
	private File localRepository = new File(userHomeDirectory() + "\\gitRepository_" + getRepoNameFromGitUrl(GIT_URI));

	public void gitInit() throws IOException, GitAPIException {

		if (!localRepository.exists() && !isGitRepository(getGitDir(), FS.DETECTED)) {
			localRepository = createGitWorkDirectory();
			cloneRepository();
		} else {
			pullRepository(localRepository);
		}

	}

	private void pullRepository(File f) throws WrongRepositoryStateException, InvalidConfigurationException,
			InvalidRemoteException, CanceledException, RefNotFoundException, RefNotAdvertisedException, NoHeadException,
			TransportException, GitAPIException, IOException {

		try (Git git = new Git(getRepo(f))) {
			PullResult call = git.pull().call();

			System.out.println("Pulled from the remote repository: " + call);
		}
	}

	private void cloneRepository() throws IOException, GitAPIException {
		// prepare a new folder for the cloned repository
		System.out.println("Cloning from " + GIT_URI + " to " + localRepository);
		Git.cloneRepository().setURI(GIT_URI).setDirectory(localRepository).setCloneAllBranches(true).call().close();
	}

	private File createGitWorkDirectory() throws IOException {
		File dir = new File(userHomeDirectory() + "\\gitRepository_" + getRepoNameFromGitUrl(GIT_URI));
		return Files.createDirectory(dir.toPath()).toFile();
	}

	private String getRepoNameFromGitUrl(String gitUrl) {
		int lastIndexOfSlash = gitUrl.lastIndexOf('/');
		int lastIndexOfDot = gitUrl.lastIndexOf('.');
		return gitUrl.substring(lastIndexOfSlash + 1, lastIndexOfDot);
	}

	private String userHomeDirectory() {
		return System.getProperty("user.home");
	}

	private String getGitPath() {
		return localRepository.getAbsolutePath() + separator + GIT_FOLDER;
	}

	private File getGitDir() {
		return new File(getGitPath());
	}

	private Repository getRepo(File f) throws IOException {
		try (Git git = Git.open(f)) {
			return git.getRepository();
		} catch (IOException e) {
			throw new IOException(e.getMessage());
		}
	}

	public static void main(String[] args) {

		App app = new App();
		try {
			app.gitInit();
			app.openrepo();
			app.XMLQuery();
		} catch (IOException | GitAPIException | XPathExpressionException | ParserConfigurationException
				| SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// resp.clear();
		System.out.println("Content-type: text/html\n\n");
		System.out.println("Hello World!");
		for (String str : resp)
			System.out.println("Seus valores sao : " + str);

	}

	public void XMLQuery() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		resp = new ArrayList<String>();
		File input = new File("MyFile");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(file);
		doc.getDocumentElement().normalize();
		String query = "/RDF/NamedIndividual/@*";
		System.out.println("Query para obter a lista das regi�es: " + query);
		XPathFactory xpathFactory = XPathFactory.newInstance();
		XPath xpath = xpathFactory.newXPath();
		XPathExpression expr = xpath.compile(query);
		NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
		for (int i = 0; i < nl.getLength(); i++) {
			System.out.println(StringUtils.substringAfter(nl.item(i).getNodeValue(), "#"));
		}

		double TesteInput = 50;
		double InfecoesInput = 50;
		double InternInput = 50;

		// pode ser '>','<' 'ou' =
		String MedTeste = "=";
		String MedInfec = "<";
		String MedIntern = ">";

		// ------------------QUERYS DE
		// ALGARVE--------------------------------------------------------

		// TESTES
		query = "//*[contains(@about,'Algarve')]/Testes/text()";
		System.out.println("Query para obter o numero de testes feitos no Algarve: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedTeste.equals(">")) {
				if (aux > TesteInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				}
			} // --------------------------------------------
			else if (MedTeste.equals("<")) {
				if (aux < TesteInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				}
			} // ------------------------------------------------------

			else if (MedTeste.equals("=")) {
				if (aux == TesteInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				} // -------------------------------------------------------
			}
		}

		System.out.println("testes no algarve e  " + expr.evaluate(doc, XPathConstants.STRING));

		// INFECOES--------------------------------------------------------------------------------------------
		query = "//*[contains(@about,'Algarve')]/Infecoes/text()";
		System.out.println("Query para obter o n�mero de infeecoes no Algarve: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("infe��es no algarve �  " + expr.evaluate(doc, XPathConstants.STRING));
		double infecAlga = (double) expr.evaluate(doc, XPathConstants.NUMBER);
		System.out.println("infecAlga e " + infecAlga);

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedInfec.equals(">")) {
				if (aux > InfecoesInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				}
			} // -------------------------------------------
			else if (MedInfec.equals("<")) {
				if (aux < InfecoesInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				}
			} // ------------------------------------------------------

			else if (MedInfec.equals("=")) {
				if (aux == InfecoesInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				} // -------------------------------------------------------
			}
		}

		// INTERN-------------------------------------------------------------------------------------------
		query = "//*[contains(@about,'Algarve')]/Internamentos/text()";
		System.out.println("Query para obter o numero de internamentos no Algarve: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("internos no algarve e  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedIntern.equals(">")) {
				if (aux > InternInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				}
			} // -------------------------------------------
			else if (MedIntern.equals("<")) {
				if (aux < InternInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				}
			} // ------------------------------------------------------

			else if (MedIntern.equals("=")) {
				if (aux == InternInput) {
					if (!resp.contains("Algarve")) {
						resp.add("Algarve");
					}
				} // -------------------------------------------------------
			}
		}

		// QUERYS DE
		// ALTENTEJO-------------------------------------------------------------------------

		// TESTES-------------------------------------------------------------------------------
		query = "//*[contains(@about,'Alentejo')]/Testes/text()";
		System.out.println("Query para obter o numero de testes feitos no Alentejo: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("testes no Alentejo e  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedTeste.equals(">")) {
				if (aux > TesteInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				}
			} // -------------------------------------------
			if (MedTeste.equals("<")) {
				if (aux < TesteInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				}
			} // ------------------------------------------------------

			if (MedTeste.equals("=")) {
				if (aux == TesteInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				} // -------------------------------------------------------
			}
		}

		// INFEC
		query = "//*[contains(@about,'Alentejo')]/Infecoes/text()";
		System.out.println("Query para obter o numero de infecoes no Alentejo: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("infecoes no Alentejo e  " + expr.evaluate(doc, XPathConstants.STRING));
		double infecAlent = (double) expr.evaluate(doc, XPathConstants.NUMBER);
		System.out.println("infecAlent e " + infecAlent);

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedInfec.equals(">")) {
				if (aux > InfecoesInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				}
			} // -------------------------------------------
			else if (MedInfec.equals("<")) {
				if (aux < InfecoesInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				}
			} // ------------------------------------------------------

			else if (MedInfec.equals("=")) {
				if (aux == InfecoesInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				} // -------------------------------------------------------
			}
		}

		// INTERN
		query = "//*[contains(@about,'Alentejo')]/Internamentos/text()";
		System.out.println("Query para obter o numero de internamentos no Alentejo: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("internos no Alentejo o  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedIntern.equals(">")) {
				if (aux > InternInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				}
			} // -------------------------------------------
			else if (MedIntern.equals("<")) {
				if (aux < InternInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				}
			} // ------------------------------------------------------

			else if (MedIntern.equals("=")) {
				if (aux == InternInput) {
					if (!resp.contains("Alentejo")) {
						resp.add("Alentejo");
					}
				} // -------------------------------------------------------
			}
		}

		// QUERYS DE
		// CENTRO-------------------------------------------------------------------------
		// TESTES
		query = "//*[contains(@about,'Centro')]/Testes/text()";
		System.out.println("Query para obter o numero de testes feitos no Centro: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("testes no Centro o  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedTeste.equals(">")) {
				if (aux > TesteInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				}
			} // -------------------------------------------
			if (MedTeste.equals("<")) {
				if (aux < TesteInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				}
			} // ------------------------------------------------------

			if (MedTeste.equals("=")) {
				if (aux == TesteInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				} // -------------------------------------------------------
			}

		}

		// INFEC-------------------------
		query = "//*[contains(@about,'Centro')]/Infecoes/text()";
		System.out.println("Query para obter o numero de infecoes no Centro: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("infe��es no Centro e  " + expr.evaluate(doc, XPathConstants.STRING));
		double infecCentro = (double) expr.evaluate(doc, XPathConstants.NUMBER);
		System.out.println("infeCentro e " + infecCentro);

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedInfec.equals(">")) {
				if (aux > InfecoesInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				}
			} // -------------------------------------------
			if (MedInfec.equals("<")) {
				if (aux < InfecoesInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				}
			} // ------------------------------------------------------

			if (MedInfec.equals("=")) {
				if (aux == InfecoesInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				} // -------------------------------------------------------
			}
		}

		// INTERN
		query = "//*[contains(@about,'Centro')]/Internamentos/text()";
		System.out.println("Query para obter o numero de internamentos no Centro: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("internos no Centro   " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedIntern.equals(">")) {
				if (aux > InternInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				}
			} // -------------------------------------------
			if (MedIntern.equals("<")) {
				if (aux < InternInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				}
			} // ------------------------------------------------------

			if (MedIntern.equals("=")) {
				if (aux == InternInput) {
					if (!resp.contains("Centro")) {
						resp.add("Centro");
					}
				} // -------------------------------------------------------
			}
		}

		// QUERYS DE
		// LISBOA-------------------------------------------------------------------------
		// TESTES
		query = "//*[contains(@about,'Lisboa')]/Testes/text()";
		System.out.println("Query para obter o n�mero de testes feitos no Lisboa: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("testes no Lisboa �  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedTeste.equals(">")) {
				if (aux > TesteInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				}
			} // -------------------------------------------
			if (MedTeste.equals("<")) {
				if (aux < TesteInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				}
			} // ------------------------------------------------------

			if (MedTeste.equals("=")) {
				if (aux == TesteInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				} // -------------------------------------------------------
			}
		}

		// INFEC-------------------------
		query = "//*[contains(@about,'Lisboa')]/Infecoes/text()";
		System.out.println("Query para obter o n�mero de infe��es no Lisboa: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("infe��es no Lisboa �  " + expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("infecAlga � " + infecCentro);

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedInfec.equals(">")) {
				if (aux > InfecoesInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				}
			} // -------------------------------------------
			if (MedInfec.equals("<")) {
				if (aux < InfecoesInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				}
			} // ------------------------------------------------------

			if (MedInfec.equals("=")) {
				if (aux == InfecoesInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				} // -------------------------------------------------------
			}
		}

		// INTERN
		query = "//*[contains(@about,'Lisboa')]/Internamentos/text()";
		System.out.println("Query para obter o n�mero de internamentos no Lisboa: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("internos no Lisboa �  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedIntern.equals(">")) {
				if (aux > InternInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				}
			} // -------------------------------------------
			if (MedIntern.equals("<")) {
				if (aux < InternInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				}
			} // ------------------------------------------------------

			if (MedIntern.equals("=")) {
				if (aux == InternInput) {
					if (!resp.contains("Lisboa")) {
						resp.add("Lisboa");
					}
				} // -------------------------------------------------------
			}
		}

		// QUERYS DE
		// NORTE-------------------------------------------------------------------------
		// TESTES
		query = "//*[contains(@about,'Norte')]/Testes/text()";
		System.out.println("Query para obter o n�mero de testes feitos no Norte: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("testes no Norte �  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedTeste.equals(">")) {
				if (aux > TesteInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				}
			} // -------------------------------------------
			if (MedTeste.equals("<")) {
				if (aux < TesteInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				}
			} // ------------------------------------------------------

			if (MedTeste.equals("=")) {
				if (aux == TesteInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				} // -------------------------------------------------------
			}
		}

		// INFEC-------------------------
		query = "//*[contains(@about,'Norte')]/Infecoes/text()";
		System.out.println("Query para obter o n�mero de infe��es no Norte: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("infe��es no Norte �  " + expr.evaluate(doc, XPathConstants.STRING));
		double infecNorte = (double) expr.evaluate(doc, XPathConstants.NUMBER);
		System.out.println("infecNorte � " + infecCentro);

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedInfec.equals(">")) {
				if (aux > InfecoesInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				}
			} // -------------------------------------------
			if (MedInfec.equals("<")) {
				if (aux < InfecoesInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				}
			} // ------------------------------------------------------

			if (MedInfec.equals("=")) {
				if (aux == InfecoesInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				} // -------------------------------------------------------
			}
		}

		// INTERN
		query = "//*[contains(@about,'Norte')]/Internamentos/text()";
		System.out.println("Query para obter o n�mero de internamentos no Norte: " + query);
		expr = xpath.compile(query);
		System.out.println(expr.evaluate(doc, XPathConstants.STRING));
		System.out.println("internos no Norte �  " + expr.evaluate(doc, XPathConstants.STRING));

		if (!expr.evaluate(doc, XPathConstants.STRING).equals("")) {// COME�A
			double aux = (double) expr.evaluate(doc, XPathConstants.NUMBER);

			if (MedIntern.equals(">")) {
				if (aux > InternInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				}
			} // -------------------------------------------
			if (MedIntern.equals("<")) {
				if (aux < InternInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				}
			} // ------------------------------------------------------

			if (MedIntern.equals("=")) {
				if (aux == InternInput) {
					if (!resp.contains("Norte")) {
						resp.add("Norte");
					}
				} // -------------------------------------------------------
			}
		}

		// RESPOSTA
		// System.out.println("Regioes que verificam seu criterios sao : " +
		// resp);

	}

	/*
	 * try { String browser =
	 * "C:\\ProgramFiles(x86)\\Google\\Chrome\\Application\\chrome.exe"; File
	 * file = new File("‪C:\\Users\\Jasmine\\Documents\\ES2\\COMP\\index.html");
	 * Runtime r = Runtime.getRuntime(); r.exec(browser + " " + file.getPath());
	 * } catch (Exception ex) { ex.printStackTrace();
	 * JOptionPane.showMessageDialog(null, "Not a valid file!", "ERROR!",
	 * JOptionPane.ERROR_MESSAGE); }
	 */

	public void runApp() throws InvalidRemoteException, TransportException, GitAPIException, IOException {
		Git.cloneRepository().setURI("https://github.com/vbasto-iscte/ESII1920")
				.setDirectory(new File("C:\\Users\\Jasmine\\git\\ESII1920")).call();
	}

	public void openrepo() throws IOException {

		// FileRepositoryBuilder repositoryBuilder = new
		// FileRepositoryBuilder();
		//
		// repository = repositoryBuilder.setGitDir(new
		// File("C:\\Users\\Jasmine\\git\\ESII1920\\.git")).readEnvironment() //
		// variables
		// .findGitDir()
		// .setMustExist(true).build();

		ObjectId lastCommitId = getRepo(localRepository).resolve(Constants.HEAD);

		try (RevWalk revWalk = new RevWalk(getRepo(localRepository))) {
			RevCommit commit = revWalk.parseCommit(lastCommitId);

			RevTree tree = commit.getTree();
			System.out.println("having tree: " + tree);

			try (TreeWalk treeWalk = new TreeWalk(getRepo(localRepository))) {
				treeWalk.addTree(tree);
				treeWalk.setRecursive(true);
				treeWalk.setFilter(PathFilter.create("covid19spreading.rdf"));
				if (!treeWalk.next()) {
					throw new IllegalStateException("nao encontrou ficheiro'covid19spreading.rdf'");
				}

				ObjectId objectId = treeWalk.getObjectId(0);
				ObjectLoader loader = getRepo(localRepository).open(objectId);

				loader.copyTo(System.out);

				// FileOutputStream out = new
				// FileOutputStream("C:\\Users\\Jasmine\\Documents\\ES2_NEON\\COMP\\target\\MyFile");
				// loader.copyTo(out);

				FileOutputStream fop = null;

				file = new File("C:\\Users\\Jasmine\\Documents\\ES2_NEON\\COMP\\target\\MyFile");
				fop = new FileOutputStream(file);

				if (file.exists()) {
					file.delete();
				}

				byte[] contentInBytes = loader.getBytes();
				fop.write(contentInBytes);
				fop.flush();
				fop.close();

			}
			// FileUtils.deleteDirectory("C:\\Users\\Jasmine\\git\\ESII1920");

			revWalk.dispose();
		}

	}
}
