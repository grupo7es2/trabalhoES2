package MyApp;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

import pl.edu.icm.cermine.ContentExtractor;
import pl.edu.icm.cermine.exception.AnalysisException;
import pl.edu.icm.cermine.metadata.model.DateType;
import pl.edu.icm.cermine.metadata.model.DocumentMetadata;


/**
*
* @author  Paulo Jin
* @version 1.0
* @since   2020-05-31 
* 
*/
public class ExtractPdfFile {

	static String Authors;
    static String Article;
    static String Journal;
    static String Publication;
    static ArrayList<String> pdfFiles;
    /**
    *
    * Generate some vanilla HTML that you usually
    * want to include at the top of any HTML page you generate.
    * @param Rows that you want to put on the page.
    * @return A String containing the top portion of an HTML file.
    *
    */
    public static String HtmlTop(String Rows)	{
		 
    	String Top = new String();
	      
	    Top = "<table border=\"1\">\n";
	    Top+= "<caption>Covid Scientific</caption>\n";
	    Top+= "<tr>\n" + 
	    		"<th>Article Title</th>\n" + 
		      	"<th>Journal name</th>\n" + 
		  		"<th>Publication year</th>\n" + 
	    		"<th>Authors</th>\n" + 
	      		"</tr>\n";	
	    Top+= Rows;
	    Top+= "</table>\n";
	    
	    return Top;

	  }
     
    
    /**
    *
    * Find all authors of the scientific article and put them in the same line.
    * @param DocumentMetadata where you will extract authors.
    * @return GEt all authors name in the same line.
    *
    */
    public static String getAuthor(DocumentMetadata article) {
		 
    	String author = "";
    	String name = null;
		 
    	for (int i = 0; i < article.getAuthors().size(); i++) {
    		if(i!=article.getAuthors().size()-1) {
    			name=article.getAuthors().get(i).getName();
    			author= ""+author+""+name+", ";
    		}
    		else
    			author= ""+author+""+name+"";
    		}
    	return author;
    }
    
	 
    /**
    * 
    * Extract metadata of the respondent pdf.
    * Create structure of the html, one row of table.
    * @param temp is a string of location of the pdf file.
    * @param URL is a string of the home page where the system will find pdf file.
    * @return A string, html code which represents a row of the table, respondent one of the pdf file.
    * @throws AnalysisException 
	* @throws IOException 
    */
    public static String createRowOfTable(String temp, String URL) throws IOException, AnalysisException {
		
		String Rows = new String();
		
		//Connect to the host 
		URL url = new URL(URL);
		java.io.InputStream in = url.openStream();
		// It will connect temp(string represent example.pdf) 
		url = new URL(temp);
        in = url.openStream();
        ContentExtractor extractor = new ContentExtractor();
        extractor.setPDF(in);
        DocumentMetadata article = extractor.getMetadata();
        Article = article.getTitle();
        Journal = article.getJournal();
        Authors= getAuthor(article);
        Publication= article.getDate(DateType.PUBLISHED).getYear();
				
        Rows += "<tr>\n" + 
				"<td><a href=" + "\"" + temp + "\">"  + Article + "</a></td>\n" + 
		   		"<td>" + Journal + "</td>\n" + 
		   		"<td>" + Publication + "</td>\n" + 
		     	"<td>" + Authors + "</td>\n" + 	    
		   		"</tr>\n";
		   		
		in.close();
		
		return Rows;
	} 
    
    
    /**
    *
    * Connect to the host.
    * Find all url of pdf file available in the web page and put them in a list.
    * For each url of pdf, extract metadata using "createRowOfTable".
    * Merge all string of metadata.   
    * @return A string which represent rows of the html table, of all pdf files.
    * @throws AnalysisException 
	* @throws IOException 
    */
	public static String htmlCode() throws IOException, AnalysisException {
		 
		 String Rows = new String();
		 String URL="http://localhost:8000/?page_id=13f"; 
		 
	     // Declare list to add the files 
	     ArrayList<String> pdfList = new ArrayList<String>(); 
	     //Regex pattern will detect if the files end with .pdf or .PDF
	     String regex = "^.*\\.(pdf|PDF)$";
	     Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
	     //This will automatically download the html page that contains the PDF and convert it to a document 
	     org.jsoup.nodes.Document document = Jsoup.connect(URL).get();
	     //Select the <a href="" > Attributes , as the pdf files are in those elements , it will also select all the <a href="" > elements 
	     Elements links =   document.select("a[href]");
	     
	     for (org.jsoup.nodes.Element content : links) {
	    	 String relHref = content.attr("href");
	    	 Matcher matcher = pattern.matcher(relHref);
	    	 while(matcher.find()) {
	    		 pdfList.add(relHref);
	    		// System.out.println(relHref);
	    	 }
	     }

	     for (String temp : pdfList) {
	    	 //Merge of all metadata
	    	 Rows+= createRowOfTable(temp,URL);
	     }

	     return Rows;
	}
	
	public static void generatedHTMLTable() {
		File f = new File("Covid_scientific.html");
		
		
	}
	
	/**
	* 
 	* Create a html tabble with metadata  
 	* @throws AnalysisException 
	* @throws IOException 
   	*
   	*/
	public static void createTableHtml() throws IOException, AnalysisException {
		String htmlcode = HtmlTop(htmlCode());
		File f = new File("/Users/paulojin/Desktop/ESII/ES2/ESII/biology/Covid_scientific.html");
		FileWriter arquivo = new FileWriter(f);
		arquivo.write(htmlcode);
		arquivo.close();
	}
	 
	/**
	*
	* @param args An array of Strings containing any command line
	* parameters supplied when this program in invoked.  Any
 	* command line parameters supplied are ignored by this routine.
 	* @throws AnalysisException 
	* @throws IOException 
   	*
   	*/
	public static void main(String[] args) throws IOException, AnalysisException {
		createTableHtml();
		String htmlcode = HtmlTop(htmlCode());
		System.out.println("Content-type: text/html\n");
		System.out.println(htmlcode);

	
	}


}
